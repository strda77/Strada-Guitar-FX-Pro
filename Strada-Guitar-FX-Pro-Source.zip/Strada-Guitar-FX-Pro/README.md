# Strada Guitar FX Pro

Fresh Android project for Strada Guitar FX Pro.

The first build provides the dark/orange user interface, preset navigation, and effect controls. The switches are currently interface-only: real-time guitar audio processing, pitch-detection tuner, and record/playback looper are not implemented yet.

GitHub Actions builds a debug APK on pushes to `main` or via **Actions → Build Strada Guitar FX Pro APK → Run workflow**. Download the artifact named `Strada-Guitar-FX-Pro-debug`.
