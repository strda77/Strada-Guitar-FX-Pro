package com.strada.guitarfXpro;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(16,17,20), panel = Color.rgb(29,31,36), orange = Color.rgb(255,132,40);
    private LinearLayout root;
    private TextView presetLabel;
    private int presetIndex = 0;
    private final String[] presets = {"Clean Glass", "Blues Drive", "Classic Rock", "British Lead", "Metal Power", "Ambient Space"};

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(bg);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(28)); scroll.addView(root); setContentView(scroll);
        TextView brand = text("STRADA",14,orange,true); brand.setLetterSpacing(.22f); root.addView(brand);
        root.addView(text("Guitar FX Pro",30,Color.WHITE,true));
        TextView subtitle = text("MULTI-EFFECTS  •  STUDIO RIG",11,Color.LTGRAY,true); subtitle.setPadding(0,dp(3),0,dp(18)); root.addView(subtitle);
        LinearLayout preset = card(); root.addView(preset); preset.addView(text("CURRENT PRESET",11,orange,true));
        presetLabel = text(presets[presetIndex],23,Color.WHITE,true); presetLabel.setPadding(0,dp(8),0,dp(12)); preset.addView(presetLabel);
        LinearLayout nav = new LinearLayout(this); preset.addView(nav); addButton(nav,"‹ PREV",()->changePreset(-1),1); addButton(nav,"NEXT ›",()->changePreset(1),1);
        TextView heading = text("EFFECT CHAIN",16,Color.WHITE,true); heading.setPadding(0,dp(20),0,dp(10)); root.addView(heading);
        String[] names={"Noise Gate","Overdrive","Distortion","Chorus","Delay","Reverb"}; String[] desc={"Reduce background noise","Warm blues and edge","High-gain drive","Width and modulation","Echo and repeats","Room and space"};
        for(int i=0;i<names.length;i++) addEffect(names[i],desc[i]);
        TextView tools = text("TOOLS",16,Color.WHITE,true); tools.setPadding(0,dp(20),0,dp(10)); root.addView(tools);
        LinearLayout toolRow = new LinearLayout(this); root.addView(toolRow);
        addButton(toolRow,"GUITAR TUNER",()->toast("Tuner real-time akan ditambahkan pada tahap audio."),1);
        addButton(toolRow,"LOOPER",()->toast("Fitur rekam dan putar loop akan ditambahkan pada tahap berikutnya."),1);
        TextView note=text("BUILD 1.0  •  AUDIO ENGINE IN DEVELOPMENT",10,Color.GRAY,false); note.setGravity(Gravity.CENTER); note.setPadding(0,dp(24),0,dp(4)); root.addView(note);
    }
    private void addEffect(String name,String description){
        LinearLayout row=card(); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(14),dp(12),dp(12),dp(12));
        LinearLayout labels=new LinearLayout(this); labels.setOrientation(LinearLayout.VERTICAL); labels.addView(text(name,16,Color.WHITE,true)); TextView d=text(description,11,Color.LTGRAY,false); d.setPadding(0,dp(4),0,0); labels.addView(d); row.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
        TextView toggle=text("OFF",12,Color.LTGRAY,true); toggle.setGravity(Gravity.CENTER); toggle.setPadding(dp(14),dp(8),dp(14),dp(8)); toggle.setBackground(roundBg(Color.rgb(50,52,58))); row.addView(toggle);
        toggle.setOnClickListener(v->{boolean on="OFF".contentEquals(toggle.getText()); toggle.setText(on?"ON":"OFF"); toggle.setTextColor(on?Color.BLACK:Color.LTGRAY); toggle.setBackground(roundBg(on?orange:Color.rgb(50,52,58))); toast(name+(on?" aktif pada antarmuka":" dinonaktifkan")+". Audio efek belum diproses di build awal.");});
    }
    private LinearLayout card(){LinearLayout b=new LinearLayout(this); b.setOrientation(LinearLayout.VERTICAL); b.setPadding(dp(16),dp(16),dp(16),dp(16)); b.setBackground(roundBg(panel)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(8); b.setLayoutParams(p); return b;}
    private void addButton(LinearLayout parent,String label,Runnable action,float weight){TextView b=text(label,12,Color.WHITE,true); b.setGravity(Gravity.CENTER); b.setPadding(dp(10),dp(13),dp(10),dp(13)); b.setBackground(roundBg(Color.rgb(54,56,63))); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,weight); p.setMargins(dp(3),dp(2),dp(3),dp(2)); parent.addView(b,p); b.setOnClickListener(v->action.run());}
    private TextView text(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private android.graphics.drawable.GradientDrawable roundBg(int color){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp(14));return d;}
    private void changePreset(int delta){presetIndex=(presetIndex+delta+presets.length)%presets.length;presetLabel.setText(presets[presetIndex]);toast("Preset dipilih: "+presets[presetIndex]);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
}
